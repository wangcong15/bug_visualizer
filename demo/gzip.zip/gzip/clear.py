import os
import sys


def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    for root, dirs, files in os.walk(current_dir):
        backup_files = [os.path.join(root, f) for f in files if f.endswith("_backup.i")]
        for backup_file in backup_files:
            os.remove(backup_file)
            print("Removed: " + backup_file)
    print('All clear!')


if __name__ == "__main__":
    main()
